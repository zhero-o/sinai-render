import json
import subprocess
import re
import whisper

AUDIO_PATH = "public/voiceover.mp3"
TIMELINE_PATH = "src/syncedTimeline.json"

ANCHORS = [
  {
    "id": "01-cold-open-question",
    "phrases": [],
    "ratio": 0.0
  },
  {
    "id": "02-garden-pull-back",
    "phrases": [
      "third chapter of genesis",
      "hear god walking",
      "pull back into the trees"
    ],
    "ratio": 0.014
  },
  {
    "id": "03-cold-open-where",
    "phrases": [
      "calls out to the man",
      "where are you"
    ],
    "ratio": 0.03
  },
  {
    "id": "04-he-made-the-trees",
    "phrases": [
      "god knows where adam is",
      "made the trees"
    ],
    "ratio": 0.038
  },
  {
    "id": "05-four-locations-strip",
    "phrases": [
      "keeps doing this",
      "in a garden",
      "open field"
    ],
    "ratio": 0.052
  },
  {
    "id": "06-four-scenes-hebrew",
    "phrases": [
      "read those four scenes",
      "asks instead of telling"
    ],
    "ratio": 0.075
  },
  {
    "id": "07-start-in-garden",
    "phrases": [
      "start in the garden",
      "eaten from the tree"
    ],
    "ratio": 0.092
  },
  {
    "id": "08-fig-leaves-hide",
    "phrases": [
      "sew fig leaves",
      "hide among the trees"
    ],
    "ratio": 0.108
  },
  {
    "id": "09-three-words-one-word",
    "phrases": [
      "english it takes three words",
      "single word",
      "ayeka"
    ],
    "ratio": 0.122
  },
  {
    "id": "10-strip-vowels",
    "phrases": [
      "ancient hebrew scrolls",
      "written without vowels",
      "take the vowel dots"
    ],
    "ratio": 0.14
  },
  {
    "id": "11-ayekah-to-eichah",
    "phrases": [
      "exact four letters spell another",
      "becomes echa",
      "becomes eichah"
    ],
    "ratio": 0.162
  },
  {
    "id": "12-lamentations-ruins",
    "phrases": [
      "opening word of the book of lamentations",
      "ruins of jerusalem",
      "babylon burned"
    ],
    "ratio": 0.18
  },
  {
    "id": "13-side-by-side-arc",
    "phrases": [
      "ancient jewish commentators",
      "look identical on the page"
    ],
    "ratio": 0.205
  },
  {
    "id": "14-rashi-open-door",
    "phrases": [
      "eleventh-century scholar rashi",
      "11th century scholar",
      "open a conversation"
    ],
    "ratio": 0.218
  },
  {
    "id": "15-sound-of-grief",
    "phrases": [
      "under the question sits the sound of grief",
      "where you have ended up"
    ],
    "ratio": 0.242
  },
  {
    "id": "16-blame-chain",
    "phrases": [
      "adam steps out",
      "points at his wife",
      "points at the serpent"
    ],
    "ratio": 0.258
  },
  {
    "id": "17-cain-abel-walk",
    "phrases": [
      "one chapter later",
      "two sons now",
      "cain and abel"
    ],
    "ratio": 0.278
  },
  {
    "id": "18-only-cain-returns",
    "phrases": [
      "only cain comes back",
      "nobody saw what happened"
    ],
    "ratio": 0.295
  },
  {
    "id": "19-ei-hevel-achicha",
    "phrases": [
      "same root word for where",
      "hevel",
      "where is abel"
    ],
    "ratio": 0.308
  },
  {
    "id": "20-progression-hide",
    "phrases": [
      "in chapter three god asked adam",
      "first a man hides from god"
    ],
    "ratio": 0.326
  },
  {
    "id": "21-blood-crying-ground",
    "phrases": [
      "already knows abel is dead",
      "blood is crying out"
    ],
    "ratio": 0.348
  },
  {
    "id": "22-cain-refuses",
    "phrases": [
      "cain refuses",
      "brother's keeper"
    ],
    "ratio": 0.368
  },
  {
    "id": "23-question-deflect",
    "phrases": [
      "answers god's question with a question",
      "ground already knows"
    ],
    "ratio": 0.382
  },
  {
    "id": "24-hagar-intro",
    "phrases": [
      "twelve chapters later",
      "third time",
      "scene turns around"
    ],
    "ratio": 0.402
  },
  {
    "id": "25-hagar-flees",
    "phrases": [
      "egyptian slave",
      "treats her so harshly",
      "hagar runs"
    ],
    "ratio": 0.416
  },
  {
    "id": "26-road-to-shur-spring",
    "phrases": [
      "pregnant and alone",
      "spring of water",
      "road to shur"
    ],
    "ratio": 0.442
  },
  {
    "id": "27-calls-her-by-name",
    "phrases": [
      "very first word he says",
      "used her name once",
      "calls her by name"
    ],
    "ratio": 0.46
  },
  {
    "id": "28-hagar-double-question",
    "phrases": [
      "uses our word again twice",
      "where have you come from"
    ],
    "ratio": 0.486
  },
  {
    "id": "29-hagar-half-answer",
    "phrases": [
      "listen to how hagar answers",
      "first half of the question",
      "second half blank"
    ],
    "ratio": 0.502
  },
  {
    "id": "30-plain-truth-promise",
    "phrases": [
      "unlike adam",
      "unlike cain",
      "tells the plain truth"
    ],
    "ratio": 0.534
  },
  {
    "id": "31-el-roi",
    "phrases": [
      "gives god a name",
      "el roi",
      "god who sees me"
    ],
    "ratio": 0.562
  },
  {
    "id": "32-elijah-carmel",
    "phrases": [
      "centuries later",
      "boldest prophet",
      "mount carmel",
      "450 prophets"
    ],
    "ratio": 0.58
  },
  {
    "id": "33-jezebel-broke",
    "phrases": [
      "queen jezebel",
      "elijah broke"
    ],
    "ratio": 0.606
  },
  {
    "id": "34-broom-tree",
    "phrases": [
      "under a broom tree",
      "take his life"
    ],
    "ratio": 0.618
  },
  {
    "id": "35-forty-days-horeb",
    "phrases": [
      "walked 40 days",
      "mount horeb",
      "inside a cave"
    ],
    "ratio": 0.632
  },
  {
    "id": "36-mah-lecha-poh",
    "phrases": [
      "hebrew isn't where",
      "what is it to you here",
      "what are you doing here"
    ],
    "ratio": 0.65
  },
  {
    "id": "37-elijah-speech-1",
    "phrases": [
      "answers with a speech",
      "rehearsing it for 40 days",
      "very zealous"
    ],
    "ratio": 0.674
  },
  {
    "id": "38-elemental-wind",
    "phrases": [
      "mouth of the cave",
      "wind tears the mountain"
    ],
    "ratio": 0.702
  },
  {
    "id": "39-elemental-quake",
    "phrases": [
      "earthquake shakes the rock"
    ],
    "ratio": 0.716
  },
  {
    "id": "40-elemental-fire",
    "phrases": [
      "fire sweeps past"
    ],
    "ratio": 0.728
  },
  {
    "id": "41-thin-silence",
    "phrases": [
      "thin silence",
      "kol de",
      "sound of a thin"
    ],
    "ratio": 0.738
  },
  {
    "id": "42-elijah-cloak-repeat",
    "phrases": [
      "wraps his cloak",
      "exact same question again"
    ],
    "ratio": 0.752
  },
  {
    "id": "43-elijah-speech-2",
    "phrases": [
      "exact same speech again",
      "too worn out"
    ],
    "ratio": 0.77
  },
  {
    "id": "44-road-back-elisha",
    "phrases": [
      "god stops asking",
      "road back",
      "student named elisha"
    ],
    "ratio": 0.788
  },
  {
    "id": "45-seven-thousand-dots",
    "phrases": [
      "7,000 other people",
      "seven thousand",
      "never the only one left"
    ],
    "ratio": 0.806
  },
  {
    "id": "46-four-moments-grid",
    "phrases": [
      "look at all four moments",
      "side by side",
      "adam hides behind trees"
    ],
    "ratio": 0.824
  },
  {
    "id": "47-god-waits-outside",
    "phrases": [
      "in all four places",
      "waits outside",
      "person speak first"
    ],
    "ratio": 0.854
  },
  {
    "id": "48-hineni-reveal",
    "phrases": [
      "one word that answers",
      "hineni",
      "hinenni"
    ],
    "ratio": 0.868
  },
  {
    "id": "49-hineni-chain",
    "phrases": [
      "abraham's name in genesis 22",
      "burning bush in exodus 3",
      "whom shall i send"
    ],
    "ratio": 0.884
  },
  {
    "id": "50-opposite-of-hiding",
    "phrases": [
      "opposite of hiding",
      "standing in the open"
    ],
    "ratio": 0.908
  },
  {
    "id": "51-every-person-hangs",
    "phrases": [
      "every person eventually ends up",
      "still hangs in the air"
    ],
    "ratio": 0.924
  },
  {
    "id": "52-isaiah-65-reversal",
    "phrases": [
      "centuries after eden",
      "isaiah chapter 65",
      "65 verse 1"
    ],
    "ratio": 0.946
  },
  {
    "id": "53-genesis-to-isaiah-finale",
    "phrases": [
      "in genesis god walks through",
      "by isaiah god is the one"
    ],
    "ratio": 0.972
  },
  {
    "id": "54-outro",
    "phrases": [
      "watched this video to the end",
      "thank you for your time",
      "please subscribe"
    ],
    "ratio": 0.988
  }
]

def get_duration(path):
    cmd = [
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", path
    ]
    return float(subprocess.check_output(cmd).decode().strip())

def norm(s):
    return re.sub(r"[^a-z0-9\s']", "", s.lower()).strip()

def main():
    duration = get_duration(AUDIO_PATH)
    print(f"Detected exact voiceover duration: {duration:.2f}s")
    print("Running Whisper (base) with word-level timestamps for 54-shot precision sync...")

    model = whisper.load_model("base")
    result = model.transcribe(AUDIO_PATH, word_timestamps=True, fp16=False)

    # Flatten all words with start times for exact phrase matching
    words = []
    for seg in result.get("segments", []):
        for w in seg.get("words", []):
            words.append((norm(w["word"]), float(w["start"])))

    full_tokens = [w[0] for w in words]

    def find_phrase_time(phrases, min_time, max_time):
        for phrase in phrases:
            p_tokens = norm(phrase).split()
            if not p_tokens:
                continue
            plen = len(p_tokens)
            for i in range(len(full_tokens) - plen + 1):
                t = words[i][1]
                if t < min_time or t > max_time:
                    continue
                if full_tokens[i:i+plen] == p_tokens:
                    return t
        return None

    with open(TIMELINE_PATH, "r", encoding="utf-8") as f:
        timeline = json.load(f)

    found = {"01-cold-open-question": 0.0}
    last_t = 0.0
    matched_count = 1

    for idx, item in enumerate(ANCHORS[1:], start=1):
        sid = item["id"]
        expected = duration * item["ratio"]
        # Search within a generous window around expected position, strictly after last_t
        min_t = max(last_t + 1.5, expected - 45.0)
        max_t = min(duration - 1.0, expected + 55.0)
        t_match = find_phrase_time(item["phrases"], min_t, max_t)
        if t_match is not None:
            t_final = max(last_t + 1.5, t_match - 0.25)
            matched_count += 1
            print(f"[synced {idx+1:02d}/54] {sid:<28} -> {t_final:6.2f}s")
        else:
            t_final = max(last_t + 2.0, expected)
            print(f"[interp {idx+1:02d}/54] {sid:<28} -> {t_final:6.2f}s")
        found[sid] = round(t_final, 2)
        last_t = t_final

    shots = timeline["shots"]
    for i, sc in enumerate(shots):
        sc["start"] = found.get(sc["id"], sc["start"])
        if i < len(shots) - 1:
            sc["end"] = found.get(shots[i + 1]["id"], duration)
        else:
            sc["end"] = round(duration + 1.5, 2)

    timeline["totalDurationSec"] = round(duration + 1.5, 2)
    timeline["hasAudio"] = True

    with open(TIMELINE_PATH, "w", encoding="utf-8") as f:
        json.dump(timeline, f, indent=2, ensure_ascii=False)

    print(f"Done! Synced {matched_count}/54 shots directly to speech words. Total length: {timeline['totalDurationSec']}s")

if __name__ == "__main__":
    main()
