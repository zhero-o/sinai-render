export type MoodType = 'void' | 'garden' | 'field' | 'desert' | 'cave' | 'storm' | 'fire' | 'silence' | 'finale';

export interface ShotSpec {
  id: string;
  start: number;
  end: number;
  visual: string;
  mood: MoodType;
  tracker: number; // 0 = hidden, 1..4 = boxes lit
  zoom?: [number, number];
  props?: Record<string, any>;
}

export interface TimelineData {
  fps: number;
  totalDurationSec: number;
  hasAudio: boolean;
  shots: ShotSpec[];
}
