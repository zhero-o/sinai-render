import React from 'react';
import { Composition } from 'remotion';
import { MainVideo } from './MainVideo';
import timelineRaw from './syncedTimeline.json';
import { TimelineData } from './types';

const timeline = timelineRaw as TimelineData;

export const RemotionRoot: React.FC = () => {
  const durationInFrames = Math.max(30, Math.ceil(timeline.totalDurationSec * timeline.fps));
  return (
    <Composition
      id="MainVideo"
      component={MainVideo}
      durationInFrames={durationInFrames}
      fps={timeline.fps}
      width={1920}
      height={1080}
    />
  );
};
