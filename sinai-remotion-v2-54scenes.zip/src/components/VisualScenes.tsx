import React from 'react';
import { AbsoluteFill, interpolate, spring, useVideoConfig } from 'remotion';
import { ShotSpec } from '../types';

const GroundLine: React.FC<{ crimson?: boolean; y?: number }> = ({ crimson = false, y = 820 }) => (
  <line
    x1="120"
    y1={y}
    x2="1800"
    y2={y}
    stroke={crimson ? 'url(#crimsonLine)' : 'url(#goldLine)'}
    strokeWidth={crimson ? 2.8 : 1.8}
  />
);

const Silhouette: React.FC<{
  x: number;
  y: number;
  scale?: number;
  flip?: boolean;
  pointing?: boolean;
  crouched?: boolean;
  seated?: boolean;
  cloaked?: boolean;
}> = ({ x, y, scale = 1, flip = false, pointing = false, crouched = false, seated = false, cloaked = false }) => {
  const sx = flip ? -scale : scale;
  return (
    <g transform={`translate(${x}, ${y}) scale(${sx}, ${scale})`}>
      {crouched ? (
        <>
          <circle cx="0" cy="-118" r="18" fill="#0b0907" stroke="#e5ba68" strokeWidth="2.2" />
          <path d="M-24,0 C-26,-55 -16,-94 0,-98 C18,-94 28,-55 24,0 Z" fill="#0b0907" stroke="#e5ba68" strokeWidth="2.2" />
        </>
      ) : seated ? (
        <>
          <circle cx="0" cy="-110" r="17" fill="#0b0907" stroke="#e5ba68" strokeWidth="2.2" />
          <path d="M-22,0 Q-20,-62 0,-88 Q24,-66 42,0 Z" fill="#0b0907" stroke="#e5ba68" strokeWidth="2.2" />
        </>
      ) : (
        <>
          <circle cx="0" cy="-178" r="19" fill="#0b0907" stroke="#e5ba68" strokeWidth="2.3" />
          <path
            d={
              cloaked
                ? 'M-30,0 L-22,-152 Q0,-168 22,-152 L32,0 Z'
                : 'M-24,0 L-18,-146 Q0,-158 18,-146 L24,0 Z'
            }
            fill="#0b0907"
            stroke="#e5ba68"
            strokeWidth="2.3"
          />
          {pointing && (
            <path d="M16,-132 L78,-122" stroke="#e5ba68" strokeWidth="3.2" strokeLinecap="round" />
          )}
        </>
      )}
    </g>
  );
};

const SvgDefs: React.FC = () => (
  <defs>
    <linearGradient id="goldLine" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stopColor="#d4a24c" stopOpacity="0" />
      <stop offset="18%" stopColor="#e5ba68" stopOpacity="0.88" />
      <stop offset="82%" stopColor="#e5ba68" stopOpacity="0.88" />
      <stop offset="100%" stopColor="#d4a24c" stopOpacity="0" />
    </linearGradient>
    <linearGradient id="crimsonLine" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stopColor="#8a2c1c" stopOpacity="0" />
      <stop offset="50%" stopColor="#d4452b" stopOpacity="0.92" />
      <stop offset="100%" stopColor="#8a2c1c" stopOpacity="0" />
    </linearGradient>
    <radialGradient id="amberGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stopColor="#fae0a5" stopOpacity="0.55" />
      <stop offset="55%" stopColor="#d4a24c" stopOpacity="0.16" />
      <stop offset="100%" stopColor="#d4a24c" stopOpacity="0" />
    </radialGradient>
    <linearGradient id="firePillar" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#fff1c1" stopOpacity="0.95" />
      <stop offset="45%" stopColor="#f59f3d" stopOpacity="0.78" />
      <stop offset="100%" stopColor="#c8431c" stopOpacity="0.1" />
    </linearGradient>
  </defs>
);

export const VisualScenes: React.FC<{
  shot: ShotSpec;
  localFrame: number;
  durationFrames: number;
}> = ({ shot, localFrame, durationFrames }) => {
  const { fps } = useVideoConfig();
  const p = Math.min(1, Math.max(0, localFrame / Math.max(1, durationFrames)));
  const t = localFrame / fps;
  const enter = spring({ frame: localFrame, fps, config: { damping: 24, stiffness: 90 } });
  const props = shot.props || {};

  const far = interpolate(p, [0, 1], [-18, 18]);
  const mid = interpolate(p, [0, 1], [-36, 36]);
  const near = interpolate(p, [0, 1], [-60, 60]);

  switch (shot.visual) {
    case 'quote-hero':
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', textAlign: 'center', padding: '0 140px' }}>
          <div style={{ opacity: enter, transform: `translateY(${interpolate(enter, [0, 1], [18, 0])}px)` }}>
            <div style={{ fontSize: 20, letterSpacing: 6, color: '#e5ba68', fontWeight: 600, marginBottom: 24 }}>
              {props.kicker}
            </div>
            <div style={{ fontSize: 102, color: '#fbf3e4', fontWeight: 600, textShadow: '0 0 42px rgba(229,186,104,0.3)' }}>
              {props.title}
            </div>
            {props.subtitle && (
              <div style={{ fontSize: 34, fontStyle: 'italic', color: 'rgba(244,234,213,0.72)', marginTop: 22 }}>
                {props.subtitle}
              </div>
            )}
          </div>
        </AbsoluteFill>
      );

    case 'hebrew-watermark-quote':
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', textAlign: 'center', padding: '0 140px' }}>
          <div
            className="hebrew"
            style={{
              position: 'absolute',
              fontSize: 340,
              color: 'rgba(229, 186, 104, 0.08)',
              letterSpacing: 16,
              transform: `scale(${interpolate(p, [0, 1], [0.96, 1.04])})`,
            }}
          >
            {props.watermark}
          </div>
          <div style={{ opacity: enter, zIndex: 2 }}>
            <div style={{ fontSize: 20, letterSpacing: 6, color: '#e5ba68', marginBottom: 24, fontWeight: 600 }}>
              {props.ref}
            </div>
            <div style={{ fontSize: 82, fontStyle: 'italic', color: '#fbf3e4', textShadow: '0 0 38px rgba(229,186,104,0.32)' }}>
              {props.quote}
            </div>
          </div>
        </AbsoluteFill>
      );

    case 'garden-hide':
    case 'garden-rays':
    case 'garden-tree': {
      const pullX = shot.visual === 'garden-hide' ? interpolate(p, [0, 1], [0, 75]) : 0;
      const isCrouched = props.stage === 'crouched';
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <GroundLine />
            {/* Far trees */}
            <g transform={`translate(${far}, 0)`} opacity="0.32">
              <path d="M360,820 L360,210 M360,410 L260,300 M360,350 L470,250" stroke="#c79541" strokeWidth="5" fill="none" />
              <path d="M1520,820 L1520,190 M1520,390 L1410,280 M1520,330 L1630,240" stroke="#c79541" strokeWidth="5" fill="none" />
            </g>
            {/* Volumetric light shafts piercing the trees */}
            {shot.visual === 'garden-rays' && (
              <g opacity={0.45 + 0.15 * Math.sin(t * 2)}>
                <polygon points="820,0 1040,0 1320,820 1020,820" fill="url(#amberGlow)" opacity="0.55" />
                <polygon points="540,0 710,0 920,820 700,820" fill="url(#amberGlow)" opacity="0.35" />
              </g>
            )}
            {/* Central Forbidden Tree if garden-tree */}
            {shot.visual === 'garden-tree' && (
              <g transform={`translate(${mid * 0.5}, 0)`}>
                <ellipse cx="960" cy="360" rx="230" ry="180" fill="url(#amberGlow)" opacity="0.4" />
                <path d="M940,820 C945,620 945,490 920,370 M980,820 C975,620 975,490 1000,370" stroke="#e5ba68" strokeWidth="3.5" fill="none" />
                <path d="M960,440 C820,420 770,280 960,220 C1150,280 1100,420 960,440 Z" fill="#0d0a07" stroke="#e5ba68" strokeWidth="2.2" />
                <Silhouette x={760} y={820} />
                <Silhouette x={840} y={820} scale={0.94} />
              </g>
            )}
            {/* Hiding behind trees */}
            {shot.visual !== 'garden-tree' && (
              <g transform={`translate(${mid}, 0)`}>
                <Silhouette x={1060 + pullX} y={820} crouched={isCrouched} />
                <Silhouette x={1130 + pullX} y={820} scale={0.93} crouched={isCrouched} />
                {/* Foreground trunks obscuring them */}
                <path d="M1220,820 C1215,600 1205,400 1235,160 C1265,380 1275,600 1265,820 Z" fill="#090705" stroke="#d4a24c" strokeWidth="2.2" />
                <path d="M510,820 C505,610 495,430 525,200 C550,390 560,610 550,820 Z" fill="#090705" stroke="#d4a24c" strokeWidth="2" />
              </g>
            )}
            {/* Foreground framing leaves */}
            <g transform={`translate(${near}, 0)`} opacity="0.7">
              <path d="M0,170 Q240,250 400,115 Q220,315 0,335 Z" fill="#080605" stroke="#b38435" strokeWidth="1.5" />
              <path d="M1920,160 Q1680,250 1510,110 Q1700,310 1920,330 Z" fill="#080605" stroke="#b38435" strokeWidth="1.5" />
            </g>
          </svg>
        </AbsoluteFill>
      );
    }

    case 'four-icons': {
      const items: string[] = props.items || [];
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', padding: '0 110px' }}>
          <div style={{ display: 'flex', gap: 38, width: '100%', maxWidth: 1540 }}>
            {items.map((label, idx) => {
              const s = spring({ frame: Math.max(0, localFrame - idx * 22), fps, config: { damping: 20, stiffness: 90 } });
              return (
                <div
                  key={label}
                  style={{
                    flex: 1,
                    padding: '44px 24px',
                    border: '1px solid rgba(229,186,104,0.48)',
                    borderRadius: 6,
                    background: 'rgba(13,10,7,0.72)',
                    textAlign: 'center',
                    opacity: s,
                    transform: `translateY(${interpolate(s, [0, 1], [24, 0])}px)`,
                  }}
                >
                  <svg viewBox="0 0 120 90" width="110" height="84" style={{ marginBottom: 18 }}>
                    {idx === 0 && <path d="M60,82 L60,46 M60,46 C34,46 30,14 60,10 C90,14 86,46 60,46 Z" fill="none" stroke="#e5ba68" strokeWidth="2.4" />}
                    {idx === 1 && <path d="M10,74 L110,74 M25,62 Q60,42 95,62" fill="none" stroke="#e5ba68" strokeWidth="2.4" />}
                    {idx === 2 && <><ellipse cx="60" cy="64" rx="40" ry="12" fill="none" stroke="#e5ba68" strokeWidth="2.4" /><path d="M14,44 Q42,26 70,40 T108,36" fill="none" stroke="#c79541" strokeWidth="1.8" /></>}
                    {idx === 3 && <path d="M18,78 C22,22 40,14 60,14 C80,14 98,22 102,78" fill="none" stroke="#e5ba68" strokeWidth="2.4" />}
                  </svg>
                  <div style={{ fontSize: 22, letterSpacing: 4, color: '#f8efe0', fontWeight: 600 }}>{label}</div>
                </div>
              );
            })}
          </div>
        </AbsoluteFill>
      );
    }

    case 'tracker-preview':
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', textAlign: 'center', padding: '0 140px' }}>
          <div style={{ opacity: enter }}>
            <div style={{ fontSize: 20, letterSpacing: 6, color: '#e5ba68', marginBottom: 24, fontWeight: 600 }}>
              {props.kicker}
            </div>
            <div style={{ fontSize: 66, color: '#fbf3e4', fontStyle: 'italic', marginBottom: 56 }}>{props.title}</div>
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
              {['GEN 3', 'GEN 4', 'GEN 16', '1 KGS 19'].map((r, i) => (
                <React.Fragment key={r}>
                  <div style={{ width: 150, padding: '16px 0', border: '1.5px dashed rgba(229,186,104,0.6)', borderRadius: 4, fontSize: 20, letterSpacing: 3, color: '#e5ba68' }}>
                    {r}
                  </div>
                  {i < 3 && <div style={{ width: 42, height: 1.5, background: 'rgba(229,186,104,0.35)' }} />}
                </React.Fragment>
              ))}
            </div>
          </div>
        </AbsoluteFill>
      );

    case 'word-compress':
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', padding: '0 120px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 90, opacity: enter }}>
            <div style={{ textAlign: 'center', width: 460 }}>
              <div style={{ fontSize: 18, letterSpacing: 5, color: 'rgba(244,234,213,0.6)', marginBottom: 18 }}>{props.leftLabel}</div>
              <div style={{ fontSize: 64, fontStyle: 'italic', color: '#f4ead5' }}>{props.leftText}</div>
            </div>
            <div style={{ fontSize: 54, color: '#e5ba68' }}>→</div>
            <div style={{ textAlign: 'center', width: 460 }}>
              <div style={{ fontSize: 18, letterSpacing: 5, color: '#e5ba68', marginBottom: 14 }}>{props.rightLabel}</div>
              <div className="hebrew" style={{ fontSize: 144, color: '#f3cb77', textShadow: '0 0 42px rgba(229,186,104,0.45)' }}>
                {props.rightHebrew}
              </div>
              <div style={{ fontSize: 30, letterSpacing: 3, color: '#e5ba68', marginTop: 8 }}>{props.translit}</div>
            </div>
          </div>
        </AbsoluteFill>
      );

    case 'vowel-strip': {
      const bareOpacity = interpolate(p, [0.32, 0.52], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', textAlign: 'center' }}>
          <div style={{ fontSize: 20, letterSpacing: 5.5, color: '#e5ba68', marginBottom: 24 }}>
            {bareOpacity > 0.5 ? 'FOUR UNVOCALIZED CONSONANTS' : 'ORIGINAL HEBREW'}
          </div>
          <div style={{ position: 'relative', height: 190, width: 900, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <div className="hebrew" style={{ position: 'absolute', fontSize: 152, color: '#f3cb77', opacity: 1 - bareOpacity }}>
              {props.full}
            </div>
            <div className="hebrew" style={{ position: 'absolute', fontSize: 152, color: '#f3cb77', letterSpacing: 26, opacity: bareOpacity, textShadow: '0 0 42px rgba(229,186,104,0.5)' }}>
              {props.bare}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 48, marginTop: 28, opacity: bareOpacity }}>
            {(props.letters || []).map((l: string) => (
              <div key={l} style={{ fontSize: 28, letterSpacing: 3, color: '#f4ead5', fontStyle: 'italic' }}>{l}</div>
            ))}
          </div>
        </AbsoluteFill>
      );
    }

    case 'vowel-swap': {
      const swap = interpolate(p, [0.38, 0.6], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', textAlign: 'center' }}>
          <div style={{ fontSize: 20, letterSpacing: 5.5, color: '#e5ba68', marginBottom: 24 }}>SAME FOUR CONSONANTS  •  NEW VOWELS</div>
          <div style={{ position: 'relative', height: 190, width: 700, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <div className="hebrew" style={{ position: 'absolute', fontSize: 152, color: '#f3cb77', opacity: 1 - swap }}>
              {props.from}
            </div>
            <div className="hebrew" style={{ position: 'absolute', fontSize: 152, color: '#f3cb77', opacity: swap, textShadow: '0 0 46px rgba(235,185,90,0.55)' }}>
              {props.to}
            </div>
          </div>
          <div style={{ fontSize: 36, fontStyle: 'italic', color: '#fbf3e4', marginTop: 22 }}>
            {swap > 0.5 ? props.toLabel : props.fromLabel}
          </div>
        </AbsoluteFill>
      );
    }

    case 'jerusalem-ruins':
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <GroundLine crimson />
            {/* Broken city wall silhouettes */}
            <g transform={`translate(${mid * 0.5}, 0)`} opacity="0.65">
              <path
                d="M280,820 L280,620 L350,620 L350,670 L420,670 L450,740 L520,740 L560,640 L640,640 L680,710 L820,710 L850,580 L940,610 L990,740 L1180,740 L1220,630 L1320,630 L1360,690 L1490,690 L1540,610 L1640,610 L1640,820 Z"
                fill="#0b0806"
                stroke="#c79541"
                strokeWidth="2"
              />
              {/* Rising smoke wisps */}
              {[480, 910, 1340].map((sx, idx) => (
                <path
                  key={sx}
                  d={`M${sx},680 Q${sx - 35 + Math.sin(t + idx) * 18},540 ${sx + 20},400`}
                  fill="none"
                  stroke="rgba(229,186,104,0.28)"
                  strokeWidth="16"
                  strokeLinecap="round"
                  style={{ filter: 'blur(12px)' }}
                />
              ))}
            </g>
          </svg>
          <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', paddingBottom: 180, textAlign: 'center', opacity: enter }}>
            <div style={{ fontSize: 20, letterSpacing: 5.5, color: '#e5ba68', marginBottom: 14 }}>{props.ref}</div>
            <div className="hebrew" style={{ fontSize: 126, color: '#f3cb77', textShadow: '0 0 40px rgba(229,186,104,0.4)' }}>{props.hebrew}</div>
            <div style={{ fontSize: 40, fontStyle: 'italic', color: '#fbf3e4', marginTop: 10 }}>{props.english}</div>
          </AbsoluteFill>
        </AbsoluteFill>
      );

    case 'arc-compare': {
      const arcOffset = interpolate(localFrame, [fps * 0.4, fps * 1.8], [720, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', padding: '0 100px', textAlign: 'center', opacity: enter }}>
          <div style={{ width: '100%', maxWidth: 1420 }}>
            <svg viewBox="0 0 1000 120" width="100%" height="110" style={{ marginBottom: -10 }}>
              <path d="M 230 105 Q 500 -20 770 105" fill="none" stroke="#e6bc6a" strokeWidth="2.6" strokeDasharray="720" strokeDashoffset={arcOffset} />
            </svg>
            <div style={{ display: 'flex', justifyContent: 'space-around', alignItems: 'flex-start' }}>
              <div style={{ width: 540 }}>
                <div style={{ fontSize: 20, letterSpacing: 5, color: '#e5ba68' }}>{props.ref1}</div>
                <div className="hebrew" style={{ fontSize: (props.heb1 || '').length > 12 ? 78 : 112, color: '#f3cb77', margin: '14px 0' }}>{props.heb1}</div>
                <div style={{ fontSize: 34, fontStyle: 'italic', color: '#f4ead5' }}>{props.eng1}</div>
              </div>
              <div style={{ width: 560 }}>
                <div style={{ fontSize: 20, letterSpacing: 5, color: '#e5ba68' }}>{props.ref2}</div>
                <div className="hebrew" style={{ fontSize: (props.heb2 || '').length > 12 ? 78 : 112, color: '#f3cb77', margin: '14px 0' }}>{props.heb2}</div>
                <div style={{ fontSize: 34, fontStyle: 'italic', color: '#f4ead5' }}>{props.eng2}</div>
              </div>
            </div>
          </div>
        </AbsoluteFill>
      );
    }

    case 'open-door': {
      const doorWidth = interpolate(p, [0, 0.7], [14, 150], { extrapolateRight: 'clamp' });
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <GroundLine />
            {/* Warm spill of light from doorway */}
            <polygon points={`${960 - doorWidth},820 ${960 + doorWidth},820 ${960 + doorWidth * 2.4},960 ${960 - doorWidth * 2.4},960`} fill="url(#amberGlow)" opacity="0.55" />
            <rect x={960 - doorWidth} y="310" width={doorWidth * 2} height="510" fill="url(#amberGlow)" stroke="#e5ba68" strokeWidth="2.2" />
            <Silhouette x={760 + p * 60} y={820} />
          </svg>
          <AbsoluteFill style={{ justifyContent: 'flex-start', alignItems: 'center', paddingTop: 155, textAlign: 'center', opacity: enter }}>
            <div style={{ fontSize: 19, letterSpacing: 5.5, color: '#e5ba68', marginBottom: 14 }}>{props.kicker}</div>
            <div style={{ fontSize: 42, fontStyle: 'italic', color: '#fbf3e4', maxWidth: 1120 }}>{props.quote}</div>
          </AbsoluteFill>
        </AbsoluteFill>
      );
    }

    case 'blame-chain': {
      const a1 = interpolate(p, [0.15, 0.38], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
      const a2 = interpolate(p, [0.45, 0.7], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <GroundLine />
            <Silhouette x={540} y={820} pointing />
            <Silhouette x={980} y={820} scale={0.94} pointing />
            {/* Coiled Serpent Silhouette */}
            <g transform="translate(1390, 820)">
              <path d="M-36,0 C-36,-28 36,-28 36,-10 C36,6 -20,-4 -18,-36 C-16,-62 18,-68 24,-84" fill="none" stroke="#e5ba68" strokeWidth="4" strokeLinecap="round" />
            </g>
            {/* Blame Arrows */}
            <g opacity={a1}>
              <line x1="650" y1="680" x2="880" y2="680" stroke="#e5ba68" strokeWidth="2.4" strokeDasharray="8 6" />
              <polygon points="885,680 868,671 868,689" fill="#e5ba68" />
            </g>
            <g opacity={a2}>
              <line x1="1090" y1="710" x2="1320" y2="755" stroke="#e5ba68" strokeWidth="2.4" strokeDasharray="8 6" />
              <polygon points="1326,756 1308,744 1304,761" fill="#e5ba68" />
            </g>
            <text x="540" y="875" textAnchor="middle" fill="#e5ba68" fontSize="22" letterSpacing="4">ADAM</text>
            <text x="980" y="875" textAnchor="middle" fill="#e5ba68" fontSize="22" letterSpacing="4">EVE</text>
            <text x="1390" y="875" textAnchor="middle" fill="#e5ba68" fontSize="22" letterSpacing="4">SERPENT</text>
          </svg>
        </AbsoluteFill>
      );
    }

    case 'field-brothers': {
      const walkTwo = interpolate(p, [0, 1], [620, 1080]);
      const walkOne = interpolate(p, [0, 1], [1160, 740]);
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <g transform={`translate(${far}, 0)`} opacity="0.4">
              <path d="M0,820 Q480,740 960,790 T1920,760 L1920,820 Z" fill="#130d09" stroke="#9e6d2c" strokeWidth="1.2" />
            </g>
            <GroundLine crimson={props.mode === 'one'} />
            {props.mode === 'two' ? (
              <>
                <Silhouette x={walkTwo} y={820} />
                <Silhouette x={walkTwo + 110} y={820} scale={0.95} />
              </>
            ) : (
              <>
                <polygon points={`${walkOne - 10},820 ${walkOne + 18},820 ${walkOne + 420},862 ${walkOne + 290},862`} fill="rgba(0,0,0,0.68)" />
                <Silhouette x={walkOne} y={820} flip />
              </>
            )}
          </svg>
        </AbsoluteFill>
      );
    }

    case 'two-step-flow':
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', padding: '0 130px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 60, opacity: enter }}>
            <div style={{ width: 520, padding: '44px 36px', border: '1px solid rgba(229,186,104,0.5)', borderRadius: 6, background: 'rgba(13,10,7,0.75)', textAlign: 'center' }}>
              <div style={{ fontSize: 18, letterSpacing: 5, color: '#e5ba68', marginBottom: 14 }}>{props.step1Ref}</div>
              <div style={{ fontSize: 42, color: '#fbf3e4', fontWeight: 600 }}>{props.step1Title}</div>
            </div>
            <div style={{ fontSize: 56, color: '#e5ba68' }}>→</div>
            <div style={{ width: 520, padding: '44px 36px', border: '1px solid rgba(212,69,43,0.65)', borderRadius: 6, background: 'rgba(20,10,8,0.78)', textAlign: 'center' }}>
              <div style={{ fontSize: 18, letterSpacing: 5, color: '#e06b55', marginBottom: 14 }}>{props.step2Ref}</div>
              <div style={{ fontSize: 42, color: '#fbf3e4', fontWeight: 600 }}>{props.step2Title}</div>
            </div>
          </div>
        </AbsoluteFill>
      );

    case 'ground-pulse':
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <GroundLine crimson />
            {[0, 1, 2].map((i) => {
              const r = ((t * 95 + i * 110) % 330);
              return (
                <ellipse
                  key={i}
                  cx="960"
                  cy="820"
                  rx={r * 1.9}
                  ry={r * 0.35}
                  fill="none"
                  stroke="#d4452b"
                  strokeWidth="2.2"
                  opacity={Math.max(0, 1 - r / 330) * 0.75}
                />
              );
            })}
          </svg>
          <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', padding: '0 180px 140px', textAlign: 'center', opacity: enter }}>
            <div style={{ fontSize: 20, letterSpacing: 5.5, color: '#e06b55', marginBottom: 20 }}>{props.ref}</div>
            <div style={{ fontSize: 48, fontStyle: 'italic', color: '#fbf3e4', lineHeight: 1.35 }}>{props.quote}</div>
          </AbsoluteFill>
        </AbsoluteFill>
      );

    case 'cain-turn-away':
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <GroundLine crimson />
            <Silhouette x={960} y={820} scale={1.18} flip />
          </svg>
          <AbsoluteFill style={{ justifyContent: 'flex-start', alignItems: 'center', paddingTop: 220, textAlign: 'center', opacity: enter }}>
            <div style={{ fontSize: 58, fontStyle: 'italic', color: '#fbf3e4', maxWidth: 1120 }}>{props.quote}</div>
          </AbsoluteFill>
        </AbsoluteFill>
      );

    case 'deflect-diagram':
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center' }}>
          <svg viewBox="0 0 1400 500" width="1400" height="500">
            <path d="M 180 250 L 660 250" stroke="#e5ba68" strokeWidth="3.5" />
            <polygon points="665,250 645,240 645,260" fill="#e5ba68" />
            <line x1="700" y1="130" x2="700" y2="370" stroke="#d4452b" strokeWidth="4" />
            <path d="M 700 250 L 1120 110" stroke="#d4452b" strokeWidth="3" strokeDasharray="10 8" opacity={interpolate(p, [0.25, 0.55], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })} />
            <text x="410" y="218" textAnchor="middle" fill="#e5ba68" fontSize="24" letterSpacing="4">GOD’S QUESTION</text>
            <text x="950" y="128" textAnchor="middle" fill="#e06b55" fontSize="24" letterSpacing="4">CAIN’S DEFLECTION</text>
          </svg>
        </AbsoluteFill>
      );

    case 'desert-wide':
    case 'desert-flee':
    case 'desert-spring': {
      const walkX = interpolate(p, [0, 1], [620, 1180]);
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <g transform={`translate(${far}, 0)`} opacity="0.45">
              <path d="M-100,820 Q360,650 860,760 T1980,710 L1980,820 Z" fill="#161009" stroke="#b8893c" strokeWidth="1.4" />
            </g>
            <g transform={`translate(${mid}, 0)`} opacity="0.75">
              <path d="M-100,820 Q520,710 1120,795 T2020,750 L2020,820 Z" fill="#100c08" stroke="#d4a24c" strokeWidth="1.8" />
            </g>
            <GroundLine />
            {shot.visual === 'desert-flee' && (
              <>
                {!props.isElijah && (
                  <path d="M220,820 L340,680 L460,820 Z" fill="#0b0806" stroke="#b8893c" strokeWidth="2" opacity="0.55" />
                )}
                <Silhouette x={walkX} y={820} cloaked={Boolean(props.isElijah)} />
              </>
            )}
            {shot.visual === 'desert-spring' && (
              <>
                <g transform="translate(980, 848)">
                  <ellipse cx="0" cy="0" rx="240" ry="28" fill="#090c0e" stroke="#e5ba68" strokeWidth="1.8" />
                  <ellipse cx="0" cy="0" rx={50 + ((t * 32) % 165)} ry={6 + ((t * 3.8) % 19)} fill="none" stroke="#f0cb7e" strokeWidth="1.3" opacity={1 - ((t * 32) % 165) / 165} />
                </g>
                <Silhouette x={660} y={820} seated />
              </>
            )}
          </svg>
          {shot.visual === 'desert-wide' && (
            <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', paddingBottom: 180, textAlign: 'center', opacity: enter }}>
              <div style={{ fontSize: 20, letterSpacing: 6, color: '#e5ba68', marginBottom: 16 }}>{props.kicker}</div>
              <div style={{ fontSize: 64, fontStyle: 'italic', color: '#fbf3e4' }}>{props.title}</div>
            </AbsoluteFill>
          )}
        </AbsoluteFill>
      );
    }

    case 'name-reveal': {
      const reveal = interpolate(p, [0.35, 0.58], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', textAlign: 'center' }}>
          <div style={{ fontSize: 34, letterSpacing: 4, color: 'rgba(244,234,213,0.4)', textDecoration: 'line-through', marginBottom: 34 }}>
            {props.crossed}
          </div>
          <div style={{ opacity: reveal, transform: `scale(${interpolate(reveal, [0, 1], [0.92, 1])})` }}>
            <div className="hebrew" style={{ fontSize: 132, color: '#f3cb77', textShadow: '0 0 42px rgba(229,186,104,0.45)' }}>{props.hebrew}</div>
            <div style={{ fontSize: 56, letterSpacing: 10, color: '#fbf3e4', fontWeight: 600, marginTop: 8 }}>{props.name}</div>
            <div style={{ fontSize: 30, fontStyle: 'italic', color: '#e5ba68', marginTop: 18 }}>{props.sub}</div>
          </div>
        </AbsoluteFill>
      );
    }

    case 'half-answer-boxes':
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', padding: '0 120px' }}>
          <div style={{ display: 'flex', gap: 56, width: '100%', maxWidth: 1420, opacity: enter }}>
            <div style={{ flex: 1, padding: '54px 42px', border: '1.8px solid #e5ba68', borderRadius: 6, background: 'rgba(229,186,104,0.1)', textAlign: 'center' }}>
              <div style={{ fontSize: 18, letterSpacing: 4.5, color: '#e5ba68', marginBottom: 24 }}>{props.leftQ}</div>
              <div style={{ fontSize: 40, fontStyle: 'italic', color: '#fbf3e4' }}>{props.leftA}</div>
            </div>
            <div style={{ flex: 1, padding: '54px 42px', border: '1.8px dashed rgba(229,186,104,0.38)', borderRadius: 6, background: 'rgba(10,8,6,0.55)', textAlign: 'center' }}>
              <div style={{ fontSize: 18, letterSpacing: 4.5, color: 'rgba(229,186,104,0.5)', marginBottom: 24 }}>{props.rightQ}</div>
              <div style={{ fontSize: 64, color: 'rgba(229,186,104,0.35)' }}>?</div>
            </div>
          </div>
        </AbsoluteFill>
      );

    case 'truth-compare': {
      const rows = [
        { name: 'ADAM', act: 'Blamed', highlight: false },
        { name: 'CAIN', act: 'Lied', highlight: false },
        { name: 'HAGAR', act: 'Told the plain truth', highlight: true },
      ];
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 26, width: 920 }}>
            {rows.map((r, i) => {
              const s = spring({ frame: Math.max(0, localFrame - i * 18), fps, config: { damping: 20, stiffness: 95 } });
              return (
                <div
                  key={r.name}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '26px 42px',
                    borderRadius: 6,
                    border: r.highlight ? '1.8px solid #e5ba68' : '1px solid rgba(229,186,104,0.28)',
                    background: r.highlight ? 'rgba(229,186,104,0.14)' : 'rgba(12,10,8,0.65)',
                    opacity: s,
                  }}
                >
                  <div style={{ fontSize: 28, letterSpacing: 5, color: r.highlight ? '#f3cb77' : 'rgba(244,234,213,0.55)', fontWeight: 700 }}>{r.name}</div>
                  <div style={{ fontSize: 36, fontStyle: 'italic', color: r.highlight ? '#ffffff' : 'rgba(244,234,213,0.6)' }}>{r.act}</div>
                </div>
              );
            })}
          </div>
        </AbsoluteFill>
      );
    }

    case 'el-roi-water':
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <g transform="translate(960, 860)">
              <ellipse cx="0" cy="0" rx="340" ry="34" fill="#090c0e" stroke="#e5ba68" strokeWidth="1.8" />
              {[0, 1].map((i) => {
                const rx = 60 + ((t * 42 + i * 130) % 260);
                return <ellipse key={i} cx="0" cy="0" rx={rx} ry={rx * 0.1} fill="none" stroke="#f0cb7e" strokeWidth="1.4" opacity={1 - rx / 320} />;
              })}
            </g>
          </svg>
          <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', paddingBottom: 140, textAlign: 'center', opacity: enter }}>
            <div style={{ fontSize: 20, letterSpacing: 5.5, color: '#e5ba68', marginBottom: 16 }}>{props.ref}</div>
            <div className="hebrew" style={{ fontSize: 138, color: '#f3cb77', textShadow: '0 0 46px rgba(235,185,90,0.5)' }}>{props.hebrew}</div>
            <div style={{ fontSize: 30, letterSpacing: 4, color: '#e5ba68', marginTop: 8 }}>{props.translit}</div>
            <div style={{ fontSize: 44, fontStyle: 'italic', color: '#fbf3e4', marginTop: 14 }}>{props.english}</div>
          </AbsoluteFill>
        </AbsoluteFill>
      );

    case 'carmel-450': {
      const fireDrop = interpolate(p, [0.45, 0.72], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <GroundLine />
            {/* Fire Pillar from Heaven */}
            <rect x="440" y="0" width="76" height={820 * fireDrop} fill="url(#firePillar)" style={{ filter: 'blur(8px)' }} />
            <Silhouette x={478} y={820} cloaked />
            <text x="478" y="878" textAnchor="middle" fill="#f3cb77" fontSize="24" letterSpacing="4">1 PROPHET</text>
            {/* 450 Prophets of Baal as crimson dots */}
            {Array.from({ length: 180 }).map((_, idx) => {
              const col = idx % 20;
              const row = Math.floor(idx / 20);
              return (
                <circle key={idx} cx={880 + col * 42} cy={620 + row * 21} r="4.2" fill="#c94b32" opacity={0.45 + 0.35 * Math.sin(idx + t * 2)} />
              );
            })}
            <text x="1280" y="878" textAnchor="middle" fill="#e06b55" fontSize="24" letterSpacing="4">450 PROPHETS OF BAAL</text>
          </svg>
        </AbsoluteFill>
      );
    }

    case 'broom-tree':
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <GroundLine />
            <g transform={`translate(${mid * 0.4}, 0)`}>
              <path d="M920,820 C915,690 935,580 960,510 M940,620 L840,540 M955,580 L1075,515" stroke="#c79541" strokeWidth="4.5" fill="none" />
              <path d="M770,560 Q950,410 1150,535 Q960,560 770,560 Z" fill="#0d0a07" stroke="#c79541" strokeWidth="2" />
              <Silhouette x={870} y={820} seated />
            </g>
          </svg>
        </AbsoluteFill>
      );

    case 'forty-days-trek': {
      const day = Math.max(1, Math.min(40, Math.round(interpolate(p, [0, 0.85], [1, 40]))));
      const walkX = interpolate(p, [0, 0.9], [280, 1460]);
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <GroundLine />
            {/* Mountain & Cave on right */}
            <path d="M1280,820 L1580,290 L1920,820 Z" fill="#0b0806" stroke="#c79541" strokeWidth="2.4" />
            <path d="M1500,820 C1505,710 1545,675 1590,675 C1635,675 1675,710 1680,820 Z" fill="#040303" stroke="#e5ba68" strokeWidth="2" />
            <Silhouette x={walkX} y={820} scale={0.78} cloaked />
          </svg>
          <AbsoluteFill style={{ justifyContent: 'flex-start', alignItems: 'center', paddingTop: 185, opacity: enter }}>
            <div style={{ fontSize: 22, letterSpacing: 6, color: '#e5ba68' }}>MOUNT HOREB  •  DAY {day} OF 40</div>
            <div style={{ width: 520, height: 3, background: 'rgba(229,186,104,0.22)', marginTop: 18, borderRadius: 2 }}>
              <div style={{ width: `${(day / 40) * 100}%`, height: '100%', background: '#e5ba68' }} />
            </div>
          </AbsoluteFill>
        </AbsoluteFill>
      );
    }

    case 'rehearsed-speech': {
      const lines = [
        '“I have been very zealous for the Lord.”',
        '“They have torn down your altars and killed your prophets.”',
        '“I am the only one left—and they are trying to kill me too.”',
      ];
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', padding: '0 150px' }}>
          <div style={{ width: '100%', maxWidth: 1200 }}>
            <div style={{ fontSize: 19, letterSpacing: 6, color: '#e5ba68', marginBottom: 34, textAlign: 'center' }}>
              {props.loop === 2 ? 'THE EXACT SAME SPEECH  •  WORD FOR WORD' : 'ELIJAH’S REHEARSED SPEECH'}
            </div>
            {lines.map((line, i) => {
              const s = spring({ frame: Math.max(0, localFrame - i * 16), fps, config: { damping: 20, stiffness: 95 } });
              return (
                <div
                  key={line}
                  style={{
                    padding: '24px 36px',
                    marginBottom: 20,
                    borderLeft: '3px solid #e5ba68',
                    background: 'rgba(14,11,8,0.72)',
                    fontSize: 34,
                    fontStyle: 'italic',
                    color: '#fbf3e4',
                    opacity: s,
                  }}
                >
                  {line}
                </div>
              );
            })}
          </div>
        </AbsoluteFill>
      );
    }

    case 'elemental-scene': {
      const isQuake = props.element === 'quake';
      const sx = isQuake ? Math.sin(localFrame * 2.1) * 9 : 0;
      const sy = isQuake ? Math.cos(localFrame * 2.5) * 6 : 0;
      return (
        <AbsoluteFill style={{ transform: `translate(${sx}px, ${sy}px)` }}>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <path d="M0,0 L1920,0 L1920,1080 L1520,1080 C1490,720 1440,340 960,290 C480,340 430,720 400,1080 L0,1080 Z" fill="#070504" stroke="#b8893c" strokeWidth="2.2" />
            <GroundLine />
            <Silhouette x={960} y={820} cloaked />
            {props.element === 'wind' &&
              [380, 460, 540, 620, 710].map((y, idx) => (
                <line key={y} x1={((t * 1150 + idx * 310) % 2100) - 400} y1={y} x2={((t * 1150 + idx * 310) % 2100) + 160} y2={y - 16} stroke="#f3cb77" strokeWidth="2.6" strokeLinecap="round" opacity="0.75" />
              ))}
            {props.element === 'quake' && (
              <path d="M460,420 L580,530 L520,640 L630,760 M1440,400 L1320,510 L1380,620 L1270,740" fill="none" stroke="#e5ba68" strokeWidth="3.2" opacity="0.8" />
            )}
            {props.element === 'fire' && (
              <ellipse cx="960" cy="790" rx="440" ry="180" fill="url(#amberGlow)" opacity="0.6" />
            )}
          </svg>
          <AbsoluteFill style={{ justifyContent: 'flex-start', alignItems: 'center', paddingTop: 175, opacity: enter }}>
            <div style={{ fontSize: 34, letterSpacing: 8, color: '#f3cb77', fontWeight: 600 }}>{props.label}</div>
          </AbsoluteFill>
        </AbsoluteFill>
      );
    }

    case 'thin-silence':
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', textAlign: 'center', padding: '0 140px' }}>
          <div style={{ opacity: enter }}>
            <div style={{ fontSize: 19, letterSpacing: 6, color: '#e5ba68', marginBottom: 22 }}>{props.ref}</div>
            <div className="hebrew" style={{ fontSize: 96, color: '#f3cb77', textShadow: '0 0 36px rgba(229,186,104,0.38)' }}>{props.hebrew}</div>
            <div style={{ width: 640, height: 1, background: 'linear-gradient(90deg, transparent, #e5ba68, transparent)', margin: '28px auto' }} />
            <div style={{ fontSize: 28, letterSpacing: 3, color: '#e5ba68', marginBottom: 12 }}>{props.translit}</div>
            <div style={{ fontSize: 42, fontStyle: 'italic', color: '#fbf3e4' }}>{props.english}</div>
          </div>
        </AbsoluteFill>
      );

    case 'cave-echo':
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <path d="M0,0 L1920,0 L1920,1080 L1520,1080 C1490,720 1440,340 960,290 C480,340 430,720 400,1080 L0,1080 Z" fill="#070504" stroke="#b8893c" strokeWidth="2.2" />
            <GroundLine />
            <Silhouette x={960} y={820} cloaked />
          </svg>
          <AbsoluteFill style={{ justifyContent: 'flex-start', alignItems: 'center', paddingTop: 210, textAlign: 'center', opacity: enter }}>
            <div style={{ fontSize: 54, fontStyle: 'italic', color: '#fbf3e4', textShadow: '0 0 32px rgba(229,186,104,0.3)' }}>{props.quote}</div>
          </AbsoluteFill>
        </AbsoluteFill>
      );

    case 'road-out-cave':
      return (
        <AbsoluteFill>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            <SvgDefs />
            <GroundLine />
            <path d="M360,820 Q960,790 1620,820" stroke="#f3cb77" strokeWidth="3.5" fill="none" strokeDasharray="1400" strokeDashoffset={interpolate(p, [0, 0.7], [1400, 0], { extrapolateRight: 'clamp' })} />
            <Silhouette x={760} y={820} cloaked />
            <Silhouette x={880} y={820} scale={0.92} />
            <text x="760" y="875" textAnchor="middle" fill="#e5ba68" fontSize="20" letterSpacing="4">ELIJAH</text>
            <text x="880" y="875" textAnchor="middle" fill="#e5ba68" fontSize="20" letterSpacing="4">ELISHA</text>
          </svg>
        </AbsoluteFill>
      );

    case 'seven-thousand-dots': {
      // Signature Ink-of-Sinai style minimalist data viz: 1 dot -> blooms into hundreds representing 7,000
      const bloom = interpolate(p, [0.18, 0.72], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
      const count = Math.round(1 + bloom * 6999);
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center' }}>
          <svg viewBox="0 0 1920 1080" width="100%" height="100%">
            {Array.from({ length: 420 }).map((_, idx) => {
              const angle = idx * 2.39996;
              const dist = Math.sqrt(idx) * 34 * bloom;
              const cx = 960 + Math.cos(angle) * dist;
              const cy = 540 + Math.sin(angle) * dist * 0.62;
              return (
                <circle
                  key={idx}
                  cx={cx}
                  cy={cy}
                  r={idx === 0 ? 7 : 3.2}
                  fill="#f3cb77"
                  opacity={idx === 0 ? 1 : Math.min(0.85, bloom * 1.4)}
                />
              );
            })}
          </svg>
          <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', textAlign: 'center' }}>
            <div style={{ fontSize: 112, fontWeight: 700, color: '#fbf3e4', textShadow: '0 0 42px rgba(0,0,0,0.95), 0 0 36px rgba(229,186,104,0.45)' }}>
              {count.toLocaleString()}
            </div>
            <div style={{ fontSize: 24, letterSpacing: 6, color: '#e5ba68', marginTop: 8, textShadow: '0 2px 14px rgba(0,0,0,0.95)' }}>
              WHO NEVER BOWED TO BAAL
            </div>
          </AbsoluteFill>
        </AbsoluteFill>
      );
    }

    case 'summary-grid': {
      const items = [
        { name: 'ADAM', place: 'Behind the trees', reason: 'Ashamed' },
        { name: 'CAIN', place: 'Behind a lie', reason: 'Guilty' },
        { name: 'HAGAR', place: 'In the desert', reason: 'Mistreated' },
        { name: 'ELIJAH', place: 'Inside a cave', reason: 'Empty' },
      ];
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', padding: '0 100px' }}>
          <div style={{ fontSize: 20, letterSpacing: 6, color: '#e5ba68', marginBottom: 42, fontWeight: 600 }}>FOUR MOMENTS SIDE BY SIDE</div>
          <div style={{ display: 'flex', gap: 32, width: '100%', maxWidth: 1520 }}>
            {items.map((item, idx) => {
              const s = spring({ frame: Math.max(0, localFrame - idx * 24), fps, config: { damping: 20, stiffness: 95 } });
              return (
                <div key={item.name} style={{ flex: 1, padding: '38px 26px', border: '1px solid rgba(229,186,104,0.48)', borderRadius: 6, background: 'rgba(14,11,8,0.75)', textAlign: 'center', opacity: s, transform: `translateY(${interpolate(s, [0, 1], [24, 0])}px)` }}>
                  <div style={{ fontSize: 26, letterSpacing: 4, color: '#e6bc6a', fontWeight: 700 }}>{item.name}</div>
                  <div style={{ fontSize: 24, color: '#f4ead5', marginTop: 18, fontStyle: 'italic' }}>{item.place}</div>
                  <div style={{ width: 48, height: 1, background: 'rgba(229,186,104,0.4)', margin: '20px auto' }} />
                  <div style={{ fontSize: 32, color: '#ffffff', fontWeight: 600 }}>{item.reason}</div>
                </div>
              );
            })}
          </div>
        </AbsoluteFill>
      );
    }

    case 'hineni-pillars': {
      const pillars = [
        { ref: 'GENESIS 22', name: 'ABRAHAM', sub: 'Called by name' },
        { ref: 'EXODUS 3', name: 'MOSES', sub: 'The burning bush' },
        { ref: 'ISAIAH 6', name: 'ISAIAH', sub: '“Send me.”' },
      ];
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', padding: '0 130px' }}>
          <div style={{ display: 'flex', gap: 46, width: '100%', maxWidth: 1420 }}>
            {pillars.map((pl, idx) => {
              const s = spring({ frame: Math.max(0, localFrame - idx * 32), fps, config: { damping: 20, stiffness: 90 } });
              return (
                <div key={pl.name} style={{ flex: 1, padding: '48px 32px', border: '1.5px solid rgba(229,186,104,0.58)', borderRadius: 6, background: 'rgba(16,12,8,0.78)', textAlign: 'center', opacity: s, transform: `translateY(${interpolate(s, [0, 1], [28, 0])}px)` }}>
                  <div style={{ fontSize: 17, letterSpacing: 5, color: '#e5ba68' }}>{pl.ref}</div>
                  <div style={{ fontSize: 34, letterSpacing: 5, color: '#fbf3e4', fontWeight: 700, marginTop: 10 }}>{pl.name}</div>
                  <div className="hebrew" style={{ fontSize: 78, color: '#f3cb77', margin: '22px 0 12px', textShadow: '0 0 28px rgba(229,186,104,0.4)' }}>הִנֵּנִי</div>
                  <div style={{ fontSize: 24, fontStyle: 'italic', color: 'rgba(244,234,213,0.78)' }}>{pl.sub}</div>
                </div>
              );
            })}
          </div>
        </AbsoluteFill>
      );
    }

    case 'outro-card':
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', textAlign: 'center', opacity: enter }}>
          <div style={{ fontSize: 20, letterSpacing: 6, color: '#e5ba68', marginBottom: 22 }}>THANK YOU FOR WATCHING</div>
          <div style={{ fontSize: 72, color: '#fbf3e4', fontWeight: 600, marginBottom: 20 }}>Like & Subscribe</div>
          <div style={{ width: 120, height: 1.5, background: '#e5ba68', margin: '18px auto 26px' }} />
          <div style={{ fontSize: 34, fontStyle: 'italic', color: '#f3cb77' }}>Jesus loves you.</div>
        </AbsoluteFill>
      );

    case 'hebrew-card':
    default:
      return (
        <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center', padding: '0 150px', textAlign: 'center', opacity: enter }}>
          {props.ref && <div style={{ fontSize: 21, letterSpacing: 5.5, color: '#e5ba68', marginBottom: 20, fontWeight: 600 }}>{props.ref}</div>}
          {props.hebrew && (
            <div className="hebrew" style={{ fontSize: props.hebrew.length > 18 ? 78 : 132, color: '#f3cb77', textShadow: '0 0 42px rgba(235,185,90,0.45)', marginBottom: 14, lineHeight: 1.25 }}>
              {props.hebrew}
            </div>
          )}
          {props.translit && <div style={{ fontSize: 28, letterSpacing: 2.5, color: 'rgba(229,186,104,0.88)', marginBottom: 18 }}>{props.translit}</div>}
          {props.english && <div style={{ fontSize: 40, fontStyle: 'italic', color: '#fbf3e4', maxWidth: 1180, lineHeight: 1.35 }}>{props.english}</div>}
        </AbsoluteFill>
      );
  }
};
