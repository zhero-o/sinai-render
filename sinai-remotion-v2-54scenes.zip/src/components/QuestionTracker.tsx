import React from 'react';

const ITEMS = [
  { ref: 'GEN 3:9', label: 'ADAM' },
  { ref: 'GEN 4:9', label: 'CAIN' },
  { ref: 'GEN 16:8', label: 'HAGAR' },
  { ref: '1 KGS 19:9', label: 'ELIJAH' },
];

export const QuestionTracker: React.FC<{ activeCount: number }> = ({ activeCount }) => {
  if (activeCount <= 0) return null;

  return (
    <div
      style={{
        position: 'absolute',
        top: 40,
        left: '50%',
        transform: 'translateX(-50%)',
        display: 'flex',
        alignItems: 'center',
        zIndex: 30,
      }}
    >
      {ITEMS.map((item, idx) => {
        const isLit = idx < activeCount;
        const isCurrent = idx === activeCount - 1;
        return (
          <React.Fragment key={item.ref}>
            <div
              style={{
                width: 162,
                padding: '8px 12px',
                borderRadius: 4,
                border: isLit
                  ? '1.5px solid rgba(229, 186, 104, 0.92)'
                  : '1.5px dashed rgba(229, 186, 104, 0.24)',
                background: isCurrent
                  ? 'rgba(229, 186, 104, 0.15)'
                  : isLit
                  ? 'rgba(229, 186, 104, 0.06)'
                  : 'rgba(10, 8, 6, 0.45)',
                boxShadow: isCurrent ? '0 0 22px rgba(229, 186, 104, 0.28)' : 'none',
                textAlign: 'center',
              }}
            >
              <div
                style={{
                  fontSize: 12,
                  letterSpacing: 2.4,
                  color: isLit ? '#e6bc6a' : 'rgba(244, 234, 213, 0.26)',
                  fontWeight: 600,
                }}
              >
                {item.ref}
              </div>
              <div
                style={{
                  fontSize: 17,
                  letterSpacing: 3,
                  marginTop: 2,
                  color: isLit ? '#fbf3e4' : 'rgba(244, 234, 213, 0.2)',
                  fontWeight: 600,
                }}
              >
                {item.label}
              </div>
            </div>
            {idx < ITEMS.length - 1 && (
              <div
                style={{
                  width: 40,
                  height: 1.5,
                  background:
                    idx < activeCount - 1
                      ? 'linear-gradient(90deg, #e6bc6a, #c79541)'
                      : 'rgba(229, 186, 104, 0.22)',
                }}
              />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};
