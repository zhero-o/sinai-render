import React, { useEffect, useRef } from 'react';
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from 'remotion';
import { MoodType } from '../types';

interface Particle {
  x: number;
  y: number;
  r: number;
  speedY: number;
  speedX: number;
  phase: number;
  alpha: number;
  warmth: number;
}

const PARTICLES: Particle[] = Array.from({ length: 185 }, (_, i) => {
  const rand = (seed: number) => {
    const x = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
    return x - Math.floor(x);
  };
  return {
    x: rand(i * 3 + 1),
    y: rand(i * 3 + 2),
    r: 1.0 + rand(i * 3 + 3) * 2.7,
    speedY: 0.007 + rand(i * 5 + 1) * 0.02,
    speedX: (rand(i * 5 + 2) - 0.5) * 0.013,
    phase: rand(i * 5 + 3) * Math.PI * 2,
    alpha: 0.16 + rand(i * 7 + 1) * 0.52,
    warmth: rand(i * 7 + 2),
  };
});

export const AtmosphericStage: React.FC<{ mood: MoodType }> = ({ mood }) => {
  const frame = useCurrentFrame();
  const { width, height, fps } = useVideoConfig();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const t = frame / fps;

  const isStorm = mood === 'storm';
  const isFire = mood === 'fire';
  const isSilence = mood === 'silence';
  const isFinale = mood === 'finale';

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, width, height);

    for (const p of PARTICLES) {
      const speedMulX = isStorm ? 14 : isSilence ? 0.12 : 1.0;
      const speedMulY = isFire ? 4.2 : isSilence ? 0.15 : 1.0;

      const px = ((p.x + t * p.speedX * speedMulX + (isStorm ? t * 0.35 : 0) + Math.sin(t * 0.45 + p.phase) * 0.01) % 1 + 1) % 1;
      const py = ((p.y - t * p.speedY * speedMulY) % 1 + 1) % 1;

      const twinkle = 0.65 + 0.35 * Math.sin(t * 1.7 + p.phase);
      const alpha = p.alpha * twinkle * (isFinale ? 1.25 : isSilence ? 0.45 : 1.0);
      const xPos = px * width;
      const yPos = py * height;
      const rad = (isFire ? p.r * 1.4 : p.r) * 3.1;

      const grad = ctx.createRadialGradient(xPos, yPos, 0, xPos, yPos, rad);
      if (isFire && p.warmth > 0.35) {
        grad.addColorStop(0, `rgba(255, 168, 72, ${Math.min(1, alpha)})`);
        grad.addColorStop(0.5, `rgba(230, 88, 28, ${alpha * 0.45})`);
        grad.addColorStop(1, 'rgba(200, 50, 10, 0)');
      } else {
        grad.addColorStop(0, `rgba(244, 206, 128, ${Math.min(1, alpha)})`);
        grad.addColorStop(0.45, `rgba(212, 162, 76, ${alpha * 0.42})`);
        grad.addColorStop(1, 'rgba(212, 162, 76, 0)');
      }

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(xPos, yPos, rad, 0, Math.PI * 2);
      ctx.fill();
    }
  }, [frame, width, height, t, isStorm, isFire, isSilence, isFinale]);

  const bgMap: Record<MoodType, string> = {
    void: 'radial-gradient(ellipse at 50% 48%, #21180e 0%, #0e0b08 56%, #060504 100%)',
    garden: 'radial-gradient(ellipse at 50% 44%, #1e1a10 0%, #0d0c08 58%, #060504 100%)',
    field: 'radial-gradient(ellipse at 50% 64%, #25150d 0%, #100b08 56%, #060504 100%)',
    desert: 'radial-gradient(ellipse at 50% 45%, #2b1d0f 0%, #130d08 58%, #070605 100%)',
    cave: 'radial-gradient(ellipse at 50% 52%, #1c150e 0%, #0c0907 56%, #050404 100%)',
    storm: 'radial-gradient(ellipse at 50% 48%, #1e1812 0%, #0c0a09 58%, #040404 100%)',
    fire: 'radial-gradient(ellipse at 50% 60%, #381a0b 0%, #150b07 56%, #060404 100%)',
    silence: 'radial-gradient(ellipse at 50% 50%, #16120c 0%, #090806 58%, #040404 100%)',
    finale: 'radial-gradient(ellipse at 50% 42%, #3d2911 0%, #161008 58%, #070605 100%)',
  };

  const shaftOpacity = isSilence ? 0.03 : isFinale ? 0.22 : 0.09 + 0.025 * Math.sin(t * 0.65);

  return (
    <AbsoluteFill style={{ background: bgMap[mood] || bgMap.void, overflow: 'hidden' }}>
      {/* Volumetric amber light shafts */}
      <div
        style={{
          position: 'absolute',
          top: '-22%',
          left: '14%',
          width: '26%',
          height: '150%',
          background:
            'linear-gradient(180deg, rgba(242,195,105,0.24) 0%, rgba(212,162,76,0.03) 72%, transparent 100%)',
          transform: `rotate(-21deg) translateX(${Math.sin(t * 0.22) * 18}px)`,
          filter: 'blur(38px)',
          opacity: shaftOpacity,
          pointerEvents: 'none',
        }}
      />
      <div
        style={{
          position: 'absolute',
          top: '-25%',
          right: '16%',
          width: '20%',
          height: '150%',
          background:
            'linear-gradient(180deg, rgba(245,205,120,0.18) 0%, rgba(212,162,76,0.02) 72%, transparent 100%)',
          transform: `rotate(-17deg) translateX(${Math.cos(t * 0.18) * 14}px)`,
          filter: 'blur(42px)',
          opacity: shaftOpacity * 0.85,
          pointerEvents: 'none',
        }}
      />
      <canvas ref={canvasRef} width={width} height={height} style={{ position: 'absolute', inset: 0 }} />
      <AbsoluteFill
        style={{
          background: 'radial-gradient(circle at center, transparent 48%, rgba(0,0,0,0.68) 100%)',
          pointerEvents: 'none',
        }}
      />
    </AbsoluteFill>
  );
};
