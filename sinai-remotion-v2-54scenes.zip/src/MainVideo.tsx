import React from 'react';
import {
  AbsoluteFill,
  Audio,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import timelineRaw from './syncedTimeline.json';
import { TimelineData } from './types';
import { AtmosphericStage } from './components/AtmosphericStage';
import { QuestionTracker } from './components/QuestionTracker';
import { VisualScenes } from './components/VisualScenes';
import './styles.css';

const timeline = timelineRaw as TimelineData;

export const MainVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const currentSec = frame / fps;

  const activeShot =
    timeline.shots.find((s) => currentSec >= s.start && currentSec < s.end) ||
    timeline.shots[timeline.shots.length - 1];

  const startFrame = Math.floor(activeShot.start * fps);
  const endFrame = Math.floor(activeShot.end * fps);
  const durationFrames = Math.max(1, endFrame - startFrame);
  const localFrame = Math.max(0, frame - startFrame);
  const p = Math.min(1, localFrame / durationFrames);

  const [z0, z1] = activeShot.zoom || [1.0, 1.05];
  const scale = interpolate(p, [0, 1], [z0, z1]);

  const fadeDur = Math.min(fps * 0.35, durationFrames * 0.25);
  const opacity = interpolate(
    localFrame,
    [0, fadeDur, Math.max(fadeDur + 1, durationFrames - fadeDur), durationFrames],
    [0, 1, 1, 0],
    { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }
  );

  return (
    <AbsoluteFill style={{ backgroundColor: '#070605' }}>
      {timeline.hasAudio && <Audio src={staticFile('voiceover.mp3')} />}
      <AtmosphericStage mood={activeShot.mood} />
      <AbsoluteFill style={{ transform: `scale(${scale})`, opacity }}>
        <VisualScenes shot={activeShot} localFrame={localFrame} durationFrames={durationFrames} />
      </AbsoluteFill>
      <QuestionTracker activeCount={activeShot.tracker} />
    </AbsoluteFill>
  );
};
